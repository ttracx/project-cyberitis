#!/bin/bash -eu

npm install -g inherits bower grunt grunt-cli