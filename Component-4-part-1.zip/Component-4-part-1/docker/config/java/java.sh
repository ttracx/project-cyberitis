export JAVA_HOME=/opt/jdk
export PATH=$PATH:$JAVA_HOME/bin

export JAVA_TOOL_OPTIONS=-Dfile.encoding=UTF-8