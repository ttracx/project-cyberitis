package io.lumify.core.model.notification;

public enum SystemNotificationSeverity {
    INFORMATIONAL,
    WARNING,
    CRITICAL
}
