package io.lumify.core.model.properties.types;

public class ByteArrayLumifyProperty extends IdentityLumifyProperty<byte[]> {
    public ByteArrayLumifyProperty(String key) {
        super(key);
    }
}
