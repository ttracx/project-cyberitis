package io.lumify.core.metrics;

public interface PausableTimerContextAware {
    void setPausableTimerContext(PausableTimerContext pausableTimerContext);
}
