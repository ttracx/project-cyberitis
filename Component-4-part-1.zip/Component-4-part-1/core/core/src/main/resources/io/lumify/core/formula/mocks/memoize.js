define([], function() {
    return function memoize(f) {
        return f;
    };
})