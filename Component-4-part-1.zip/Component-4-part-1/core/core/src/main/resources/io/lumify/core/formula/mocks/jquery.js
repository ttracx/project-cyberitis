define([], function() {
    return $;
})