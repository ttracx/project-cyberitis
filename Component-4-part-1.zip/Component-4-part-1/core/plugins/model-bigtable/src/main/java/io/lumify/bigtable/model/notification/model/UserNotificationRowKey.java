package io.lumify.bigtable.model.notification.model;

import com.altamiracorp.bigtable.model.RowKey;

public class UserNotificationRowKey extends RowKey {

    public UserNotificationRowKey(String rowKey) {
        super(rowKey);
    }
}
