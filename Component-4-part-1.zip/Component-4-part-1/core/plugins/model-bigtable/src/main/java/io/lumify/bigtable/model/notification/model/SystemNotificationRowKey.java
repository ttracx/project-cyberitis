package io.lumify.bigtable.model.notification.model;

import com.altamiracorp.bigtable.model.RowKey;

public class SystemNotificationRowKey extends RowKey {

    public SystemNotificationRowKey(String rowKey) {
        super(rowKey);
    }
}
