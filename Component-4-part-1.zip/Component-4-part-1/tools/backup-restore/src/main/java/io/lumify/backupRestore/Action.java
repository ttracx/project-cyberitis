package io.lumify.backupRestore;

public enum Action {
    BACKUP,
    RESTORE
}
