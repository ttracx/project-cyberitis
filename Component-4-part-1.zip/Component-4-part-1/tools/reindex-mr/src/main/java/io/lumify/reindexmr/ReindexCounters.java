package io.lumify.reindexmr;

public enum ReindexCounters {
    ELEMENTS_PROCESSED
}
