
This tool re-indexes the data using an MR job.

## Reindex via Map Reduce

        yarn jar lumify-reindex-mr-*-jar-with-dependencies.jar vertex

## Reindex via IDE

1. Run `io.lumify.reindexmr.ReindexMR vertex` from the module `lumify-wikipedia-mr`
