package io.lumify.assignimagemr;

public enum AssignImageCounters {
    ELEMENTS_PROCESSED,
    ASSIGNMENTS_MADE
}
