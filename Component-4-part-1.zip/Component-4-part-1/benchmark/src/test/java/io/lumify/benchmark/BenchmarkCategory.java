package io.lumify.benchmark;

/**
 * Use this with {@link org.junit.experimental.categories.Category annotations} on tests that are measuring performance.
 */
public interface BenchmarkCategory {
}
