package io.lumify.migrations;

public enum MigrationCounters {
    ELEMENTS_VIEWED,
    ELEMENTS_MIGRATED
}
